https://www.notion.so/Build-an-unsupervised-auto-encoder-prototype-using-public-datasets-of-external-eye-images-9d46a0f3e7f145b298ab0cf34f8edbd4
