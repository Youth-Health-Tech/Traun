import os
import cv2
import ast
import torch.nn as nn
from torchvision import datasets, models, transforms
from torch.utils.data import DataLoader, Dataset
import pandas as pd
from sklearn.model_selection import train_test_split
import torch
import torchvision
import random
from torch.utils.data import DataLoader, Dataset
import json
import ast
from torchvision import transforms
from PIL import Image
from torchvision import datasets, models, transforms
import torch.nn as nn
import torch.optim as optim
import numpy as np
import time
import copy
from tqdm import tqdm
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay
import wandb
from PIL import Image
import skimage
import matplotlib.pyplot as plt
import torchvision.transforms.functional as F
from sklearn.metrics import roc_auc_score
from sklearn.metrics import f1_score


# dataset_images_root = "EyePacs1KDataset"
# Try using the iris cropped images to train the model
dataset_images_root = os.path.join("EyePacs1KDataset", "normalized_eye_image_dataset", "iris_cropped_results")

dataset_csv_root = "EyePacs1KDatasetCSV"


## Helper functions for EyePacs* notebooks

def moderate_dr_plus(row, left_or_right):  
    positive_labels = ["Moderate NPDR", "Proliferative DR", "Severe NPDR"]
    negative_labels = ["No DR", "Mild DR"]
    dr_level_colname = f"dr_level_{left_or_right}"
    if row[dr_level_colname] in positive_labels:
        return True
    elif row[dr_level_colname] in negative_labels:
        return False
    else:
        raise Exception("Unknown label: {}".format(row[dr_level_colname]))

def vtdr(row, left_or_right):  
    positive_labels = ["Proliferative DR", "Severe NPDR"]
    negative_labels = ["No DR", "Mild DR", "Moderate NPDR"]
    dr_level_colname = f"dr_level_{left_or_right}"
    if row[dr_level_colname] in positive_labels:
        return True
    elif row[dr_level_colname] in negative_labels:
        return False
    else:
        raise Exception("Unknown label: {}".format(row[dr_level_colname]))


def dr_nodr(row, left_or_right):  
    positive_labels = ["Mild DR", "Moderate NPDR", "Proliferative DR", "Severe NPDR"]
    negative_labels = ["No DR"]
    dr_level_colname = f"dr_level_{left_or_right}"
    if row[dr_level_colname] in positive_labels:
        return True
    elif row[dr_level_colname] in negative_labels:
        return False
    else:
        raise Exception("Unknown label: {}".format(row[dr_level_colname]))
    
def split_eyes(row):
    left_eye_images, right_eye_images = split_eyes_to_lists(row)
    left_eye_image = None 
    right_eye_image = None
    if len(left_eye_images) > 0:
        left_eye_image = left_eye_images[0]
    if len(right_eye_images) > 0:
        right_eye_image = right_eye_images[0]
    return (left_eye_image, right_eye_image)

def split_eyes_to_lists(row):
    left_eye_images = [] 
    right_eye_images = []

    eye_image_filenames_raw = row["eye_image_filenames"]
    if isinstance(eye_image_filenames_raw, list):
        eye_image_filenames = eye_image_filenames_raw
    else:
        eye_image_filenames = ast.literal_eval(eye_image_filenames_raw)
        
    for eye_image in eye_image_filenames:
        if "left" in eye_image.lower():
            left_eye_images.append(eye_image)
        elif "right" in eye_image.lower():
            right_eye_images.append(eye_image)
        else:
            print("Warning: unknown eye image: {}".format(eye_image))
        
    return (left_eye_images, right_eye_images)

def initialize_model(model_name, num_classes, final_dropout, use_pretrained=True):
    # Initialize these variables which will be set in this if statement. Each of these
    #   variables is model specific.
    model_ft = None

    if model_name == "inception":
        """ Inception v3
        Be careful, expects (299,299) sized images and has auxiliary output
        """
        model_ft = models.inception_v3(pretrained=use_pretrained)
        # set_parameter_requires_grad(model_ft, feature_extract)

        # Handle the auxilary net
        num_ftrs = model_ft.AuxLogits.fc.in_features
        model_ft.AuxLogits.fc = nn.Linear(num_ftrs, num_classes)
        # Handle the primary net
        num_ftrs = model_ft.fc.in_features
        model_ft.fc = nn.Linear(num_ftrs,num_classes)

        # Update the dropout in final layer
        model_ft.dropout = nn.Dropout(final_dropout)
    elif model_name == "resnet":
        
        model_ft = models.resnet18(pretrained=use_pretrained)
        num_ftrs = model_ft.fc.in_features
        model_ft.fc = nn.Linear(num_ftrs, num_classes)

        # TODO: Resnet doesn't have a dropout layer, so we should consider adding one
        # See https://discuss.pytorch.org/t/inject-dropout-into-resnet-or-any-other-network/66322
    elif model_name == "resnet50":
        
        model_ft = models.resnet50(pretrained=use_pretrained)
        num_ftrs = model_ft.fc.in_features
        model_ft.fc = nn.Linear(num_ftrs, num_classes)

    elif model_name == "vgg":
        model_ft = models.vgg11_bn(pretrained=use_pretrained)
        num_ftrs = model_ft.classifier[6].in_features
        model_ft.classifier[6] = nn.Linear(num_ftrs,num_classes)

        # TODO: Does VGG have a dropout layer?  If not, we should consider adding one

    else:
        print("Invalid model name, exiting...")
        exit()

    return model_ft

def explode_dataset_per_eye(source_df):
    new_df_list = []
    for _, row in source_df.iterrows():
        left_eye_images, right_eye_images = split_eyes_to_lists(row)

        # Workaround for mislabeled data issue where there either two labeled left eyes 
        # or two labeled right eyes, even though in reality one of the eyes is mislabeled 
        # as left when it should be right, or vice-versa.  This is a problem because 
        # it makes the left_right_dr_mismatch column very misleading.  Detect those
        # cases and and explicitly set left_right_dr_mismatch to False.
        if len(left_eye_images) >= 2 or len(right_eye_images) >= 2:
            left_right_dr_mismatch = False
        else:
            left_right_dr_mismatch = row["left_right_dr_mismatch"]

        # Append all left eye images (normally just 1, but sometimes more)
        for left_eye_img in left_eye_images:
            left_or_right = "lft"
            dr_level = row["dr_level_lft"]
            dme = row["dme_lft"]
            if dr_level == "Ungradable":
                continue
            new_df_list.append(
                [row["case_id"], 
                left_eye_img, 
                "lft",
                dr_level, 
                dme, 
                moderate_dr_plus(row, left_or_right), 
                vtdr(row, left_or_right), 
                dr_nodr(row, left_or_right),
                left_right_dr_mismatch
                ])
            
        # Append all right eye images (normally just 1, but sometimes more)
        for right_eye_img in right_eye_images:
            left_or_right = "rt"
            dr_level = row["dr_level_rt"]
            dme = row["dme_rt"]
            if dr_level == "Ungradable":
                continue
            new_df_list.append([
                row["case_id"], 
                right_eye_img, 
                "rt",  
                dr_level, 
                dme, 
                moderate_dr_plus(row, left_or_right), 
                vtdr(row, left_or_right), 
                dr_nodr(row, left_or_right),
                left_right_dr_mismatch
                ])

    # Create a dataframe from collected list
    df_subset = pd.DataFrame(
                new_df_list, 
                columns=[
                    'case_id', 
                    'image_path', 
                    'left_or_right_eye',
                    'dr_level',
                    'dme',
                    'moderate_dr_plus',
                    'vtdr',
                    'dr_nodr',
                    'left_right_dr_mismatch'
                ]
            )

    return df_subset

class EyePacs1KDataset(Dataset):
    
    def __init__(self, dataframe, dataset_images_root, transform, target_label, rgb):
        super().__init__()
        self.dataframe = dataframe
        self.dataset_images_root = dataset_images_root
        self.transform = transform
        self.target_label = target_label
        
        # If true, rgb.
        # If false, grayscale
        self.rgb = rgb

    def __getitem__(self, index):
        
        input_img_path = self.dataframe.iloc[index]["image_path"]
        img_path_basename = os.path.basename(input_img_path)
        image_path = os.path.join(self.dataset_images_root, img_path_basename)

        # Convert to RGB since there are a few unexpected grayscale images in the dataset
        if self.rgb:
            image = Image.open(image_path).convert("RGB")
        else:
            image = Image.open(image_path).convert("L")

        # Convert from True/False to 1/0
        label_bool = self.dataframe.iloc[index][self.target_label]
        if label_bool == True:
            # Use "1" as the class index of the DR class
            label = 1
        else:
            # Use "0" as the class index of the no DR class
            label = 0

        # Apply transformations
        if self.transform:
            
            # Convert PIL image to numpy array
            image_np = np.array(image)

            # Apply transformations
            augmented = self.transform(image=image_np)
            
            # Convert numpy array to PIL Image
            # image = Image.fromarray(augmented['image'])
            image = augmented['image']

        return image, label

    def __len__(self):
        return len(self.dataframe) 
    
    
def get_mean_std(loader):
    channels_sum, channels_squared_sum, num_batches = 0, 0, 0
    for data, _ in loader:

        # Calculate mean across dimensions:
        #  - 0: all images in the batch
        #  - 2: width
        #  - 3: height
        channels_sum += torch.mean(data, dim=[0, 2, 3])
        channels_squared_sum += torch.mean(data ** 2, dim=[0, 2, 3])
        num_batches += 1

    mean = channels_sum / num_batches
    std = ((channels_squared_sum / num_batches) - (mean ** 2)) ** 0.5

    return mean, std


def freeze_unfreeze_all_base_weights(model_name, model, freeze: bool):
    if model_name == "inception":
        fc_layer_names = [
            "AuxLogits.fc.weight", 
            "AuxLogits.fc.bias",
            "fc.weight",
            "fc.bias"
        ]
    elif model_name.startswith("resnet"):
        fc_layer_names = [
            "fc.weight",
            "fc.bias"
        ]
    elif model_name == "vgg":
        fc_layer_names = [
            "classifier.0.weight",
            "classifier.0.bias",
            "classifier.3.weight",
            "classifier.3.bias",
            "classifier.6.weight",
            "classifier.6.bias"
        ]
    else:
        raise ValueError(f"Model name {model_name} not supported")

    for name, param in model.named_parameters():
        if name in fc_layer_names:
            # Never want to freeze fc layers, and they will never need to be unfrozen either
            continue            
        param.requires_grad = not freeze
        
def unfreeze_final_layer_classifier_weights(model_name, model, only_unfreeze_classifier):
    """
    Unfreeze the final cnn and classifier weights for training
    """
    if not model_name.startswith("resnet"):
        raise Exception("Only works with resnet")
        
    if only_unfreeze_classifier:
        layer_names_to_unfreeze = [
            "fc.weight",
            "fc.bias"
        ]
    else:
        
        if model_name.startswith("resnet50"):
            raise Exception("Not implemented for resnet50")
        
        layer_names_to_unfreeze = [
            # "layer4.0.conv1.weight",
            # "layer4.0.bn1.weight",
            # "layer4.0.bn1.bias",
            # "layer4.0.conv2.weight",
            # "layer4.0.bn2.weight",
            # "layer4.0.bn2.bias",
            # "layer4.0.downsample.0.weight",
            # "layer4.0.downsample.1.weight",
            # "layer4.0.downsample.1.bias",
            "layer4.1.conv1.weight",
            "layer4.1.bn1.weight",
            "layer4.1.bn1.bias",
            "layer4.1.conv2.weight",
            "layer4.1.bn2.weight",
            "layer4.1.bn2.bias",
            "fc.weight",
            "fc.bias",
        ]


    for name, param in model.named_parameters():
        if name in layer_names_to_unfreeze:
            param.requires_grad = True
        else:
            param.requires_grad = False

def show_frozen_weights(model):
    for name, param in model.named_parameters():
        print(f"{name}: {param.requires_grad}")

def calc_precision_recall_stats(TP, FN, TN, FP):

    N = (TP + FN + TN + FP)

    accuracy  = (TP + TN)  / N
    if (TP + FP) == 0:
        precision = 0
    else:
        precision = TP / (TP + FP)

    if (TP + FN) == 0:
        recall = 0
    else:
        recall    = TP / (TP + FN)
    
    return accuracy, precision, recall

def train_model(model, dataloaders, criterion, optimizer, lr_scheduler, num_epochs, phases, device, is_inception=False, wandb_config=None):
    
    since = time.time()

    validation_preds_epoch = []    
    validation_labels_epoch = []    
    val_acc_history = []

    best_model_wts = copy.deepcopy(model.state_dict())
    best_validation_roc_auc = 0.0

    for epoch in range(num_epochs):
        print('Epoch {}/{}'.format(epoch, num_epochs - 1))
        print('-' * 10)

        # Each epoch typically has a training and validation phase, eg phases = ['train', 'val']
        for phase in phases:
            if phase == 'train':
                model.train()  # Set model to training mode
            else:
                model.eval()   # Set model to evaluate mode

                # Save snapshots of the validation predictions and labels to generate a confusion matrix
                validation_preds_epoch = []    
                validation_labels_epoch = []    

            # Metrics
            running_loss = 0.0
            running_corrects = 0
            running_TP = 0
            running_TN = 0
            running_FP = 0
            running_FN = 0
            running_F1_SCORE = 0
            running_ROC_AUC = 0.0

            # Iterate over data.
            for inputs, labels in tqdm(dataloaders[phase]):
                inputs = inputs.to(device)
                labels = labels.to(device)

                # Reshape labels from [label_1, label_2, ...] to [[label_1], [label_2], ...
                # Eg, [[1.],[0.],[1.],..]
                labels_reshaped = labels.reshape(-1, 1).float()

                # zero the parameter gradients
                optimizer.zero_grad()

                # forward pass
                # track history if only in train
                with torch.set_grad_enabled(phase == 'train'):
                    # Get model outputs and calculate loss
                    # Special case for inception because in training it has an auxiliary output. In train
                    #   mode we calculate the loss by summing the final output and the auxiliary output
                    #   but in testing we only consider the final output.
                    if is_inception and phase == 'train':
                        # From https://discuss.pytorch.org/t/how-to-optimize-inception-model-with-auxiliary-classifiers/7958
                        outputs, aux_outputs = model(inputs)

                        loss1 = criterion(outputs, labels_reshaped)
                        loss2 = criterion(aux_outputs, labels_reshaped)
                        
                        loss = loss1 + 0.4*loss2
                    else:
                        outputs = model(inputs)
                        loss = criterion(outputs, labels_reshaped)

                    # Run through sigmoid to get the probability of the prediction being positive
                    # This will look like: [[0.3645],[0.3524],[0.3290],..]
                    outputs_sigmoid = torch.sigmoid(outputs)

                    # Calculate ROC AUC
                    labels_reshaped_detached = labels_reshaped.detach().cpu()
                    outputs_sigmoid_detached = outputs_sigmoid.detach().cpu()
                    try:
                        roc_auc = roc_auc_score(y_true=labels_reshaped_detached, y_score=outputs_sigmoid_detached)
                    except ValueError:
                        print(f"Warning: ROC AUC score could not be calculated for epoch {epoch} and phase {phase}.  Using 0.0")
                        roc_auc = 0.0

                    # Get the predictions in a true/false format
                    preds = outputs_sigmoid > 0.5

                    # Anything greater than 0.5 is a positive prediction.
                    # In reality this is the same as checking if the labels are equal to 1.0, because
                    # the labels are either 0.0 or 1.0
                    labels_reshaped_true_false = labels_reshaped > 0.5 
                                        
                    # Add to running stats for tracking precision and recall
                    TP = torch.logical_and(preds == True, labels_reshaped_true_false == True).sum().item()
                    FP = torch.logical_and(preds == True, labels_reshaped_true_false == False).sum().item()
                    TN = torch.logical_and(preds == False, labels_reshaped_true_false == False).sum().item()
                    FN = torch.logical_and(preds == False, labels_reshaped_true_false == True).sum().item()

                    running_TP += TP
                    running_FP += FP
                    running_TN += TN
                    running_FN += FN

                    if phase == 'val':
                        validation_preds_epoch.extend(preds.cpu().numpy())
                        validation_labels_epoch.extend(labels.cpu().numpy())

                    # backward + optimize only if in training phase
                    if phase == 'train':
                        loss.backward()
                        optimizer.step()

                # statistics
                running_loss += loss.item() * inputs.size(0)
                running_corrects += torch.sum(preds == labels_reshaped_true_false)
                running_ROC_AUC += roc_auc * inputs.size(0)

            # End of current epoch
            epoch_loss = running_loss / len(dataloaders[phase].dataset)
            epoch_acc = running_corrects.double() / len(dataloaders[phase].dataset)
            epoch_ROC_AUC = running_ROC_AUC / len(dataloaders[phase].dataset)
            _, epoch_precision, epoch_recall = calc_precision_recall_stats(running_TP, running_FN, running_TN, running_FP)
            epoch_F1 = 2 * (epoch_precision * epoch_recall) / (epoch_precision + epoch_recall)

            print('{} Loss: {:.4f} F1: {:.4f} Acc: {:.4f} ROCAUC: {:.4f} Precision: {:.4f} Recall: {:.4f} LR: {}'.format(phase, epoch_loss, epoch_F1, epoch_acc, epoch_ROC_AUC, epoch_precision, epoch_recall, lr_scheduler.get_last_lr()))
            wandb.log({
                "epoch": epoch, 
                f"{phase}_epoch_acc": epoch_acc, 
                f"{phase}_epoch_f1": epoch_F1, 
                f"{phase}_epoch_roc_auc": epoch_ROC_AUC, 
                f"{phase}_epoch_loss": epoch_loss,
                f"{phase}_epoch_precision": epoch_precision,
                f"{phase}_epoch_recall": epoch_recall
            })

            # deep copy the model
            if phase == 'val' and epoch_ROC_AUC > best_validation_roc_auc:
                best_validation_roc_auc = epoch_ROC_AUC
                best_model_wts = copy.deepcopy(model.state_dict())
            if phase == 'val':
                val_acc_history.append(epoch_acc)
                
            if phase == 'train':
                # Learning rate scheduler step
                lr_scheduler.step()

        if phase == 'val' and epoch > 0 and epoch % 10 == 0:
            # Save the model at the end of every 10 epochs.  This isn't necessarily the best model, but it's a good checkpoint
            
            # Create a wandb artifact for saving model checkpoints
            model_artifact = wandb.Artifact("inceptionv3",  # TODO: pass in actual model type as a param
                                            type="model",
                                            description="Inception v3 model trained on Eyepacs1K dataset",
                                            metadata=dict(wandb_config)
            )

            model_filename = f"model-epoch-{epoch}.pt"
            torch.save(model.state_dict(), model_filename)


    # End of training
    time_elapsed = time.time() - since
    print('Training complete in {:.0f}m {:.0f}s'.format(time_elapsed // 60, time_elapsed % 60))
    
    print('Best val ROC AUC: {:4f}'.format(best_validation_roc_auc))

    # If this training run includes a validation phase, return the model with the best validation accuracy 
    if 'val' in phases:
        model.load_state_dict(best_model_wts)

    return model, val_acc_history, validation_preds_epoch, validation_labels_epoch, best_validation_roc_auc


class CustomRescaleTransform:
    
    """
    Custom transformation (augmentation) to rescale by one of the given rescale factors chosen at random, 
    followed by center cropping to the given crop size.
    
    Should be able to achieve the equivalent of nature paper scale factor:
    
    1.0X (60%) 1.3X (20%) 1.5X (20%)
    
    """

    def __init__(self, crop_size, rescale_factors):
        self.crop_size = crop_size
        self.rescale_factors = rescale_factors
        if len(self.rescale_factors) != 2:
            raise Exception("Expects exactly 2 rescale factors")

    def __call__(self, x):
        
        random_number = random.random() 
        if random_number > 0.6:
            
            if random_number > 0.8:
                rescale_factor = self.rescale_factors[0]
            else:
                rescale_factor = self.rescale_factors[1]
        
            # Convert from PIL to nparray to feed to skimage
            image_np = np.array(x)

            # multichannel=True needed so it doesn't change the number of channels
            # see https://stackoverflow.com/questions/64619498/skimage-transform-rescale-adds-an-extra-dimension-to-input-image
            scale_out = skimage.transform.rescale(image_np, scale=rescale_factor, mode='constant', anti_aliasing=True, multichannel=True)

            scale_out_unnorm = scale_out * 255

            # Convert from nparray back to PIL
            image_scale_out = Image.fromarray(scale_out_unnorm.astype('uint8'), 'RGB')

            # Center crop at the given crop size
            cropped = transforms.CenterCrop(self.crop_size)(image_scale_out)
            
            return cropped
        else:
            return x

        
## Helper functions for Autoencoder and ExtractRoboflow* notebooks

def iris_dataset_crop_and_write_super_bboxes(target_dir_path, super_bboxes_and_filenames):
    """
    Given an array of dictionaries:
      [{"file_path": .., "bbox": [..]}, ...]
    
    write all of the cropped files to the target_dir_path using the following steps:
    
    1. For each super_bboxes_and_filename
    2. Open the image file at file_path
    3. Use bbox to crop
    4. Write out cropped image to target_dir_path/{file_path}
    """
    image_file_names = []
    for super_bboxes_and_filename in super_bboxes_and_filenames:
        try:
            file_name = super_bboxes_and_filename["file_name"]
            file_path = os.path.join(os.getcwd(), "Iris-Detection-1/train", file_name)
            assert os.path.exists(file_path)
            image = cv2.imread(file_path)
            x_min, y_min, w, h = super_bboxes_and_filename["bbox"]
            crop_img = image[y_min:y_min+h, x_min:x_min+w]
            cropped_path = os.path.join(target_dir_path, file_name)
            cv2.imwrite(cropped_path, crop_img)
            image_file_names.append(file_name)
        except Exception as e:
            print(f"Skipping {file_name} due to exception: {e}.  crop_img: {crop_img.shape}")
    print(f"Wrote {len(super_bboxes_and_filenames)} cropped images to {target_dir_path}")
    return image_file_names

def eye_dataset_crop_and_write_super_bboxes(target_dir_path, super_bboxes_and_filenames):
    """
    Given an array of dictionaries:
        [{"file_path": .., "bbox": [..]}, ...]

    write all of the cropped files to the target_dir_path using the following steps:

    1. For each super_bboxes_and_filename
    2. Open the image file at file_path
    3. Use bbox to crop
    4. Write out cropped image to target_dir_path/{file_path}
    """

    image_file_names = []
    for super_bboxes_and_filename in super_bboxes_and_filenames:
        try:
            file_name = super_bboxes_and_filename["file_name"]
            file_path = os.path.join(os.getcwd(), "Eye-Detection-3/train", file_name)
            assert os.path.exists(file_path)
            image = cv2.imread(file_path)
            x_min, y_min, w, h = super_bboxes_and_filename["bbox"]["eye1"]
            crop_img = image[y_min:y_min+h, x_min:x_min+w]
            cropped_path = os.path.join(target_dir_path, file_name[:-4]+"_eye_1.jpg")
            cv2.imwrite(cropped_path, crop_img)
            image_file_names.append(file_name)
            x_min, y_min, w, h = super_bboxes_and_filename["bbox"]["eye2"]
            crop_img = image[y_min:y_min+h, x_min:x_min+w]
            cropped_path = os.path.join(target_dir_path, file_name[:-4]+"_eye_2.jpg")
            cv2.imwrite(cropped_path, crop_img)
            image_file_names.append(file_name)
        except Exception as e:
                print(f"Skipping {file_name} due to exception: {e}.  crop_img: {crop_img.shape}")
    print(f"Wrote {len(super_bboxes_and_filenames)*2} cropped images to {target_dir_path}")
    return image_file_names

def iris_dataset_extract_super_bounding_boxes(coco_train, cat_ids):
    results = [] 
    # All images have every single category (except 0, which no images have).  So no
    # need to consider all categories, just pick a single category and find all the
    # images with that category.  Another approach would be to loop over all images
    # and then de-dupe already seen image ids.
    img_ids = coco_train.getImgIds(catIds=[1])
    for img_id in img_ids:
        img_info = coco_train.loadImgs([img_id])[0]
        img_file_name = img_info["file_name"]
        ann_ids = coco_train.getAnnIds(imgIds=img_id, iscrowd=None)
        anns = coco_train.loadAnns(ann_ids)

        result = {
            "file_name": img_file_name,
            "bbox": iris_dataset_extract_super_bounding_box_coords(anns),
            "img_id": img_id
        }

        results.append(result)
            
    return results

def eye_dataset_extract_super_bounding_boxes(coco_train, cat_ids):
    results = []
    # All images have every single category (except 0, which no images have).  So no
    # need to consider all categories, just pick a single category and find all the
    # images with that category.  Another approach would be to loop over all images
    # and then de-dupe already seen image ids.
    img_ids = coco_train.getImgIds(catIds=[1])
    for img_id in img_ids:
        img_info = coco_train.loadImgs([img_id])[0]
        img_file_name = img_info["file_name"]
        ann_ids = coco_train.getAnnIds(imgIds=img_id, iscrowd=None)
        annotations = coco_train.loadAnns(ann_ids)

        result = {
            "file_name": img_file_name,
            "bbox": eye_dataset_extract_super_bounding_box_coords(annotations),
            "img_id": img_id,
        }

        results.append(result)
            
    return results

def iris_dataset_extract_super_bounding_box_coords(annotations_for_image):
    """
    Given annotations for an image that contain a _single_ super bounding box
    (see https://universe.roboflow.com/eyedetection/iris-detection/images/0uUTMJxwG7otCgHzB9ul for a visual depiction)
    return the [x_min, y_min, width, height] of the super bounding box.
    
    Algorithm: 
    
    1. Extract a list of all the X values, then sort it ascending
    2. Extract a list of all the Y values, then sort it ascending
    3. Take first elements of both lists, that is X min and Y min
    4. Take the last (greatest) elements of both lists, use those to calculate the width and height
    """
    
    annotations_for_image = validate_duplicate_categories(annotations_for_image)

    bboxes = [
        annotation["bbox"] for annotation in annotations_for_image
    ]
    xvals = [
        bbox[0] for bbox in bboxes
    ]
    xvals.sort()
    x_min = xvals[0]

    yvals = [
        bbox[1] for bbox in bboxes
    ]
    yvals.sort()
    y_min = yvals[0]
    
    x_max = xvals[-1]
    y_max = yvals[-1]
    
    height = y_max - y_min
    width = x_max - x_min
    
    return [x_min, y_min, width, height]

def eye_dataset_extract_super_bounding_box_coords(annotations_for_image):
    """
    Given annotations for an image that contains two super bounding boxes
    return the [x_min, y_min, width, height] of both super bounding boxes.
    
    Algorithm: 
    
    1. Identify the individual bounding boxes using "category_id" of each annotation dict_
    2. Extract the x and y values of the super bounding box(i.e the x and y values of top-left most box)
    3. Add the width and height of consecutive bounding boxes horizontally and vertically respectively to calculate width and height of super bounding box
    """

    #separate bounding boxes of both eyes
    #Each eye's super bounding box is made of 8 bboxes identified by category_id 1->8
    anns_eye1 = []
    anns_eye2 = []
    for i in range(len(annotations_for_image)):
        if i <= 7:
            anns_eye1.append(annotations_for_image[i])
        else:
            anns_eye2.append(annotations_for_image[i])
    
    anns_eye1 = super_bbbox_dimensions_calculation(anns_eye1)
    anns_eye2 = super_bbbox_dimensions_calculation(anns_eye2)

    return {"eye1": anns_eye1, "eye2": anns_eye2}

def super_bbbox_dimensions_calculation(annotations):
    validate_duplicate_categories(annotations)
    x = annotations[0]["bbox"][0] + annotations[0]["bbox"][2]
    y = annotations[0]["bbox"][1]
    width = annotations[1]["bbox"][2]
    height = annotations[0]["bbox"][3] + annotations[3]["bbox"][3] + annotations[5]["bbox"][3]

    return [x, y, width, height]

def validate_duplicate_categories(annotations_for_image):
    """
    This method removes annotations with duplicate categories
    to avoid multiple instances of images
    """
    anns = []
    set_of_anns_id = set()
    for annotation in annotations_for_image:
        if annotation["category_id"] not in set_of_anns_id:
            set_of_anns_id.add(annotation["category_id"])
            anns.append(annotation)
    return anns

def show_pytorch_image_grid(imgs):
    if not isinstance(imgs, list):
        imgs = [imgs]
    fig, axs = plt.subplots(ncols=len(imgs), squeeze=False)
    for i, img in enumerate(imgs):
        img = img.detach()
        img = F.to_pil_image(img)
        axs[0, i].imshow(np.asarray(img))
        axs[0, i].set(xticklabels=[], yticklabels=[], xticks=[], yticks=[])


def renormalize_image(tensor):
    """
    Renormalize a tensor to [0, 1]
    See https://discuss.pytorch.org/t/why-do-images-look-weird-after-imagenet-normalization/92071/3
    """
    minFrom= tensor.min()
    maxFrom= tensor.max()
    minTo = 0
    maxTo=1
    return minTo + (maxTo - minTo) * ((tensor - minFrom) / (maxFrom - minFrom))


def undersample(df, label, label_value_with_excess):

    # Find the indexes of the rows that have the label value with excess
    indexes_excess_group = df[df[label] == label_value_with_excess]

    # Find the indexes of the non-excess group
    indexes_non_excess_group = df[df[label] != label_value_with_excess]
    
    # Sample the excess group to match the size of the non-excess group
    indexes_excess_group_sampled = indexes_excess_group.sample(len(indexes_non_excess_group))

    # Concatenate the two groups into a new dataframe
    df_undersampled = df.iloc[indexes_excess_group_sampled.index | indexes_non_excess_group.index]

    return df_undersampled